package com.controleur;

import com.model.*;
import com.sun.org.apache.xml.internal.utils.XMLReaderManager;
import org.xml.sax.SAXException;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Observable;

/**
 * Créé par Pierre
 * à 12/12/2016.
 */
public class ControleurBDD{
    private static Connection c = null;


    /**
     * Methode initialisant l'objet Connection permettant l'accés a la BDD
     * @param arg
     * @param s
     */
    public static void connect(String arg, String s){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            c= DriverManager.getConnection("jdbc:mysql://localhost:3306/mail",arg,s);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Database connection failed");
            e.printStackTrace();
        }
    }

    /**
     *
     * @return l'objet connection
     */
    public static Connection getConnection(){
        return c;
    }

    /**
     * Cette methode va aller chercher dans la table Utilisateurs de la base de donnée l'utilisateur correspondant aux identifiants en parramètres.
     * Si il n'existe aucune correspondance ou bien qu'il y a plus de deux résultats, la methode renvoie null
     *
     * @param addrMail
     * @param mdp
     * @return Un objet de type Utilisateur contenant l'adresse email de l'utilisateur;
     */
    public static Utilisateur connection(String addrMail, String mdp){
        Utilisateur utilisateur = null;
        try{
            PreparedStatement ps = c.prepareStatement("" +
                    "SELECT *" +
                    "FROM mail.utilisateurs " +
                    "WHERE adresseUtilisateur=? AND mdp=?;");

            ps.setString(1,addrMail);
            ps.setString(2,mdp);
            ResultSet rs = ps.executeQuery();
            rs.beforeFirst();
            if(rs.next()) {
                rs.first();
                utilisateur = new Utilisateur(rs.getString("adresseUtilisateur"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return utilisateur;
    }


    /**
     * Cette methode va modifier les valeurs de l'utilisateur dans la base de donnée.
     *
     * @param u
     * @param champ
     * @param valeur
     */
    public static void MAJutilisateur(Utilisateur u, ChampsUtilisateur champ, String valeur){
        try{
            PreparedStatement ps = c.prepareStatement("" +
                    "UPDATE mail.utilisateurs SET ? = ?" +
                    "WHERE adresseUtilisateur=?; ");

            ps.setString(1,champ.toString());
            ps.setString(2,valeur);
            ps.setString(3,u.getAdresse());
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /**
     * Crée un utilisateir classique (les champs parlent d'eux même)
     * @param addrMail
     * @param nom
     * @param prenom
     * @param dateNaissance
     * @param numtel
     * @param mdp
     */
    public static void creerUtilisateur(String addrMail, String nom, String prenom, Date dateNaissance, String numtel, String mdp){
        try {
            PreparedStatement ps = c.prepareStatement("" +
                    "INSERT INTO mail.utilisateurs VALUES(?,?,?,?,?,?,0);");
            ps.setString(1,addrMail);
            ps.setString(2,nom);
            ps.setString(3,prenom);
            ps.setDate(4,dateNaissance);
            ps.setString(5,numtel);
            ps.setString(6,mdp);
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Methode permettant "d'envoyer" un mail
     *
     * @param uExp
     * @param uDest
     * @param objet
     * @param message
     */
    public static void envoyerMail(Utilisateur uExp, Utilisateur uDest, String objet, String message){
        try{
            PreparedStatement ps = c.prepareStatement("" +
                    "INSERT INTO mail.mails(adresseExpediteur, adresseDestinataire, objet, texte, date) VALUES(?,?,?,?,?);");
            ps.setString(1,uExp.getAdresse());
            ps.setString(2,uDest.getAdresse());
            ps.setString(3,objet);
            ps.setString(4,message);
            ps.setDate(5, new Date(Calendar.getInstance().getTimeInMillis()));
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Methode permettant de récupérer une collection contennant tout les ID des mails reçu par l'utilisateur passé en parramètre.
     *
     * @param uDest
     * @return
     */
    public static List<Mail> recupererMails(Utilisateur uDest){
        ArrayList<Mail> mailArrayList= null;
        try{
            PreparedStatement ps = c.prepareStatement("" +
                    "SELECT idMail " +
                    "FROM mail.mails \n" +
                    "WHERE adresseDestinataire=? ;");
            ps.setString(1,uDest.getAdresse());
            ResultSet rs = ps.executeQuery();
            mailArrayList = new ArrayList<>(rs.getRow());
            rs.beforeFirst();
            while(rs.next()) {
                mailArrayList.add(new Mail(rs.getInt("idMail")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return mailArrayList;
    }

    /**
     * Cette methode vérifie si l'utilisateur u existe.
     * @param u
     * @return true si u existe dans la bdd, false sinon
     */
    public static boolean exists(Utilisateur u) {
        boolean exists = false;

        try{
            PreparedStatement ps = c.prepareStatement("SELECT *" +
                    "FROM utilisateurs \n" +
                    "WHERE adresseUtilisateur=?;");
            ps.setString(1,u.getAdresse());
            ResultSet rs = ps.executeQuery();
            rs.beforeFirst();
            exists = rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exists;
    }

    public static void closeConnection(){
        try {
            c.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
