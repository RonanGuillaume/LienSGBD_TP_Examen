package com.controleur;

/**
 * Créé par Pierre
 * à 12/12/2016.
 *
 * Liste les champs modifiables de la table utilisateur.
 */
public enum ChampsUtilisateur {
    nom("String",true),
    prenom("String",true),
    dateNaissance("Date",true),
    numTel("String",true),
    mdp("String",true),
    administrateur("boolean",false);

    private final String type;
    private final boolean mofiable;

    ChampsUtilisateur(String type, boolean modifiable) {
        this.type=type;
        this.mofiable=modifiable;
    }

    public String getType() {
        return type;
    }

    public boolean isMofiable() {
        return mofiable;
    }
}
