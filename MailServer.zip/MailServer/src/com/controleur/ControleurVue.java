package com.controleur;

import com.Vue.Vue;
import com.model.Administrateur;
import com.model.Mail;
import com.model.Utilisateur;

import javax.swing.*;
import java.sql.Date;
import java.util.List;

/**
 * Créé par Pierre
 * à 12/12/2016.
 */
public class ControleurVue {

    private Utilisateur utilisateur=null;
    private Administrateur admin = null;

    public ControleurVue(){
        Vue vue = new Vue(this);
        vue.pack();
        vue.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        vue.setVisible(true);
    }

    public boolean connect(String id, String mdp){
        utilisateur = ControleurBDD.connection(id, mdp);

        if(utilisateur!=null)
            if (utilisateur.estAdmin())
                admin = new Administrateur(utilisateur.getAdresse());

        return utilisateur != null;
    }

    public void deconnecter(){
        utilisateur=null;
        admin=null;
    }

    public boolean envoyerMail(String dest, String objet, String message){
        Utilisateur uDest = new Utilisateur(dest);
        if(ControleurBDD.exists(uDest)) {
            ControleurBDD.envoyerMail(utilisateur, uDest, objet, message);
            return true;
        } else
            return false;
    }

    public boolean creerCompte(String email, String mdp, String nom, String prenom, Date dateNaissance, String numTel){
        if(!ControleurBDD.exists(new Utilisateur(email))){
            ControleurBDD.creerUtilisateur(email,nom,prenom,dateNaissance,numTel,mdp);
            return true;
        }
        else{
            return false;
        }
    }

    public boolean estAdmin(){
        return admin!=null;
    }

    //peut être précharger dans l'objet Mail les données pour éviter des accés multiples a la base de donnée dans la vue
    public List<Mail> getMailList(){
        return ControleurBDD.recupererMails(utilisateur);
    }

}
