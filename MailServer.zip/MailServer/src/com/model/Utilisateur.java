package com.model;

import com.DAO.Utilisateur_DAO;
import com.controleur.ChampsUtilisateur;

import java.sql.Date;


/**
 * Créé par Pierre
 * à 12/12/2016.
 *
 * Je ne ferais pas de javadoc pour cette classe, les noms parlent d'eux même.
 */
public class Utilisateur {
    private String adresse;

    public Utilisateur(String adresse) {
        this.adresse = adresse;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getNom(){
        return Utilisateur_DAO.getChamp(this, ChampsUtilisateur.nom);
    }

    public void setNom(String nom){
        Utilisateur_DAO.setChamp(this, ChampsUtilisateur.nom,nom);
    }

    public String getPrenom(){
        return Utilisateur_DAO.getChamp(this, ChampsUtilisateur.prenom);
    }

    public void setPrenom(String prenom){
        Utilisateur_DAO.setChamp(this, ChampsUtilisateur.prenom,prenom);
    }

    public Date getDateDeNaissance(){
        String date = Utilisateur_DAO.getChamp(this, ChampsUtilisateur.dateNaissance);
        if(date!= null)
            return new Date(Long.parseLong(date));
        return null;
    }

    public void setDateDeNaissance(Date date){
        Utilisateur_DAO.setChamp(this, ChampsUtilisateur.dateNaissance,date.toString());
    }

    public String getNumTel(){
        return Utilisateur_DAO.getChamp(this, ChampsUtilisateur.numTel);
    }

    public void setNumTel(String numTel){
        Utilisateur_DAO.setChamp(this, ChampsUtilisateur.numTel,numTel);
    }

    public boolean estAdmin(){
        return Boolean.parseBoolean(Utilisateur_DAO.getChamp(this, ChampsUtilisateur.administrateur));
    }

}
