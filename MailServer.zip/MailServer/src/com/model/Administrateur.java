package com.model;

import com.controleur.ControleurBDD;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

/**
 * Créé par Pierre
 * à 13/12/2016.
 */
public class Administrateur extends Utilisateur {
    public Administrateur(String adresse) {
        super(adresse);
    }

    public static double moyenneMailParUtilisateur(){
        try {
            PreparedStatement ps = ControleurBDD.getConnection().prepareStatement("" +
                    "SELECT COUNT(*)" +
                    "FROM mail.mails;");
            ResultSet rs = ps.executeQuery();

            rs.first();
            int nbMails=rs.getInt(1);

            PreparedStatement ps2 = ControleurBDD.getConnection().prepareStatement("" +
                    "SELECT COUNT(*)" +
                    "FROM mail.utilisateurs;");
            rs = ps2.executeQuery();
            rs.first();
            return ((double)nbMails)/((double)rs.getInt(1));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }


    public static int mailsEnvoyeSemaine(){
        try{
            PreparedStatement ps = ControleurBDD.getConnection().prepareStatement("" +
                    "SELECT COUNT(*)" +
                    "FROM mail.mails " +
                    "WHERE date > ?;");
            ps.setDate(1, new Date(Calendar.getInstance().getTimeInMillis()-604800000));
            ResultSet rs = ps.executeQuery();
            rs.first();
            return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    //Fonctions statistiques
}
