package com.model;

import com.DAO.Mail_DAO;


import java.sql.Date;
import java.util.Observable;

/**
 * Créé par Julien
 * à 12/12/2016.
 */
public class Mail extends Observable {
    private int id;


    public Mail(int id){
        this.id = id;
    }

    public int getId(){
        return id;
    }

    public Utilisateur getExpediteur(){
        return Mail_DAO.getExpediteur(id);
    }

    public Utilisateur getDestinataire(){
        return Mail_DAO.getDestinataire(id);
    }

    public String getTexte(){
        return Mail_DAO.getTexte(id);
    }

    public void setTexte(String texte){
        Mail_DAO.setTexte(id,texte);
    }

    public String getObjet(){
        return Mail_DAO.getObjet(id);
    }

    public void setObjet(String objet){
        Mail_DAO.setObjet(id, objet);
    }

    public Date getDate(){
        return Mail_DAO.getDate(id);
    }

    @Override
    public String toString() {
        return "de : " + getDestinataire().getAdresse() + "  Objet : " + getObjet();
    }
}