package com;

import com.controleur.ControleurBDD;
import com.controleur.ControleurVue;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;


public class Main {

    public static void main(String[] args) throws ParserConfigurationException, SAXException {

//        Scanner sc = new Scanner(System.in);
//        System.out.println("id bdd");
//        String idBdd = sc.nextLine();
//        System.out.println("mdp bdd");
//        String mdpBdd = sc.nextLine();


        ControleurBDD.connect("","");
        ControleurVue controleurVue = new ControleurVue();
    }
}

//Et parce que j'en avais envie, voici une jolie licorne :

//        /((((((\\\\
//=======((((((((((\\\\\
//     ((           \\\\\\\
//     ( (*    _/      \\\\\\\
//       \    /  \      \\\\\\________________
//        |  |   |       </                  ((\\\\
//        o_|   /        /                      \ \\\\    \\\\\\\
//             |  ._    (                        \ \\\\\\\\\\\\\\\\
//             | /                       /       /    \\\\\\\     \\
//     .______/\/     /                 /       /         \\\
//    / __.____/    _/         ________(       /\
//   / / / ________/`---------'         \     /  \_
//  / /  \ \                             \   \ \_  \
// ( <    \ \                             >  /    \ \
//  \/      \\_                          / /       > )
//           \_|                        / /       / /
//                                    _//       _//
//                                   /_|       /_|

//Superbe, n'est ce pas ?