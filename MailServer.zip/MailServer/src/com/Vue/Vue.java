package com.Vue;

import com.controleur.ControleurBDD;
import com.controleur.ControleurVue;
import com.model.Administrateur;
import com.model.Mail;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;

/**
 * Créé par Pierre
 * à 12/12/2016.
 */
public class Vue extends JFrame{
    private JPanel mainPanel;
    private JPanel authentificationPanel;
    private JPanel userPanel;
    private JPanel adminPanel;
    private JTextField idField;
    private JPasswordField passwordField;
    private JButton connectionButton;
    private JPanel createMailPanel;
    private JPanel toolsPanel;
    private JButton creerNouveauMailButton;
    private JButton arreterLeditionDeButton;
    private JButton reprendreLeditionDeButton;
    private JTextField destinataireField;
    private JTextField objetField;
    private JTextArea textArea;
    private JButton envoyerButton;
    private JLabel messageLabel;
    private JButton creerUnCompteButton;
    private JPanel creationComptePanel;
    private JTextField emailField;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;
    private JTextField nomField;
    private JTextField prenomField;
    private JTextField dateNaissanceDayField;
    private JTextField telField;
    private JButton creerMonCompteButton;
    private JTextField dateNaissanceMoisField;
    private JTextField dateNaissanceAnneeField;
    private JLabel errorLabel;
    private JButton seDeconnecterButton;
    private JButton administrationButton;
    private JButton quiterModeAdminButton;
    private JPanel afficherMail;
    private JList<Object> mailList;
    private JTextPane mailAffiche;
    private JButton cacherMailsButton;
    private JButton afficherMailsButton;
    private JButton rafraichirButton;
    private JButton nombreDeMailParButton;
    private JLabel nbMailsLabel;
    private JButton nombreMailCetteSemaineButton;
    private JLabel mailsWeekLabel;

    private ControleurVue controleur;

    public Vue(ControleurVue controleur){
        this.controleur=controleur;

        setContentPane(mainPanel);

        userPanel.setVisible(false);
        adminPanel.setVisible(false);
        authentificationPanel.setVisible(true);
        creationComptePanel.setVisible(false);
        createMailPanel.setVisible(false);
        afficherMail.setVisible(false);

        administrationButton.setVisible(false);
        arreterLeditionDeButton.setVisible(false);
        reprendreLeditionDeButton.setVisible(false);
        messageLabel.setVisible(false);
        envoyerButton.setVisible(false);
        errorLabel.setVisible(false);
        cacherMailsButton.setVisible(false);
        afficherMailsButton.setVisible(true);


        connectionButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                if(controleur.connect(idField.getText(), passwordField.getText())){
                    authentificationPanel.setVisible(false);
                    userPanel.setVisible(true);
                    passwordField.setText("");
                    mailAffiche.setText("");

                    if(controleur.estAdmin()){
                        administrationButton.setVisible(true);
                    }
                    creerNouveauMailButton.setVisible(true);
                    pack();
                }
            }
        });

        creerNouveauMailButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                createMailPanel.setVisible(true);
                creerNouveauMailButton.setVisible(false);
                arreterLeditionDeButton.setVisible(true);
                envoyerButton.setVisible(true);
                messageLabel.setVisible(false);
                pack();
            }
        });
        arreterLeditionDeButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                createMailPanel.setVisible(false);
                reprendreLeditionDeButton.setVisible(true);
                arreterLeditionDeButton.setVisible(false);
                envoyerButton.setVisible(false);
                messageLabel.setVisible(false);
            }
        });
        reprendreLeditionDeButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                createMailPanel.setVisible(true);
                reprendreLeditionDeButton.setVisible(false);
                envoyerButton.setVisible(true);
                arreterLeditionDeButton.setVisible(true);
                pack();
            }
        });
        envoyerButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                if(controleur.envoyerMail(destinataireField.getText(),objetField.getText(),textArea.getText())){
                    destinataireField.setText("");
                    objetField.setText("");
                    textArea.setText("");
                    messageLabel.setForeground(Color.GREEN);
                    messageLabel.setText("Message envoyé");
                    messageLabel.setVisible(true);
                }
                else{
                    messageLabel.setForeground(Color.RED);
                    messageLabel.setText("Les destinataire est inconnu");
                    messageLabel.setVisible(true);
                }
                pack();
            }
        });


        creerUnCompteButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                creationComptePanel.setVisible(true);
                authentificationPanel.setVisible(false);
                pack();
            }
        });
        creerMonCompteButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    Date date = new Date(Integer.parseInt(dateNaissanceAnneeField.getText()),Integer.parseInt(dateNaissanceMoisField.getText()),Integer.parseInt(dateNaissanceDayField.getText()));
                    if (passwordField1.getText().equals(passwordField2.getText()) && (!emailField.getText().equals(""))) {
                        if (controleur.creerCompte(emailField.getText(), passwordField1.getText(), nomField.getText(), prenomField.getText(), date, telField.getText())) {
                            controleur.connect(emailField.getText(), passwordField1.getText());
                            creationComptePanel.setVisible(false);
                            userPanel.setVisible(true);
                            errorLabel.setVisible(false);

                            emailField.setText("");
                            passwordField1.setText("");
                            passwordField2.setText("");
                            nomField.setText("");
                            prenomField.setText("");
                            dateNaissanceDayField.setText("");
                            dateNaissanceAnneeField.setText("");
                            dateNaissanceMoisField.setText("");
                            telField.setText("");
                            pack();
                        }
                        else{
                            errorLabel.setVisible(true);
                        }
                    }
                    else{
                        errorLabel.setVisible(true);
                    }
                }catch (Exception ex){
                    errorLabel.setVisible(true);
                }
                pack();
            }
        });

        seDeconnecterButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                userPanel.setVisible(false);
                adminPanel.setVisible(false);
                authentificationPanel.setVisible(true);
                creationComptePanel.setVisible(false);
                createMailPanel.setVisible(false);

                arreterLeditionDeButton.setVisible(false);
                reprendreLeditionDeButton.setVisible(false);
                messageLabel.setVisible(false);
                envoyerButton.setVisible(false);

                textArea.setText("");
                destinataireField.setText("");
                objetField.setText("");

                controleur.deconnecter();
                pack();
            }
        });

        administrationButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                if(controleur.estAdmin()){
                    adminPanel.setVisible(true);
                    userPanel.setVisible(false);
                    pack();
                }
            }
        });
        quiterModeAdminButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                userPanel.setVisible(true);
                adminPanel.setVisible(false);
                pack();
            }
        });

        mailList.addListSelectionListener(new ListSelectionListener() {
            /**
             * Called whenever the value of the selection changes.
             *
             * @param e the event that characterizes the change.
             */
            @Override
            public void valueChanged(ListSelectionEvent e) {
                Mail selectedMail = (Mail) mailList.getSelectedValue();
                if (selectedMail!=null)
                    mailAffiche.setText(selectedMail.getTexte());
            }
        });
        cacherMailsButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                afficherMail.setVisible(false);
                afficherMailsButton.setVisible(true);
                cacherMailsButton.setVisible(false);
            }
        });
        afficherMailsButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                afficherMail.setVisible(true);
                cacherMailsButton.setVisible(true);
                afficherMailsButton.setVisible(false);
                mailList.setListData(controleur.getMailList().toArray());
                pack();
            }
        });
        rafraichirButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                mailList.setListData(controleur.getMailList().toArray());
            }
        });
        nombreDeMailParButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                nbMailsLabel.setText(String.valueOf(Administrateur.moyenneMailParUtilisateur()));
                pack();
            }
        });
        nombreMailCetteSemaineButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                mailsWeekLabel.setText(String.valueOf(Administrateur.mailsEnvoyeSemaine()));
            }
        });
    }

    /**
     * Releases all of the native screen resources used by this
     * {@code Window}, its subcomponents, and all of its owned
     * children. That is, the resources for these {@code Component}s
     * will be destroyed, any memory they consume will be returned to the
     * OS, and they will be marked as undisplayable.
     * <p>
     * The {@code Window} and its subcomponents can be made displayable
     * again by rebuilding the native resources with a subsequent call to
     * {@code pack} or {@code show}. The states of the recreated
     * {@code Window} and its subcomponents will be identical to the
     * states of these objects at the point where the {@code Window}
     * was disposed (not accounting for additional modifications between
     * those actions).
     * <p>
     * <b>Note</b>: When the last displayable window
     * within the Java virtual machine (VM) is disposed of, the VM may
     * terminate.  See <a href="doc-files/AWTThreadIssues.html#Autoshutdown">
     * AWT Threading Issues</a> for more information.
     *
     * @see Component#isDisplayable
     * @see #pack
     * @see #show
     */
    @Override
    public void dispose() {
        super.dispose();
        ControleurBDD.closeConnection();
    }
}