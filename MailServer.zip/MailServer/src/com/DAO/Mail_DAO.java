package com.DAO;

import com.controleur.*;
import com.model.*;

import java.sql.Connection;
import java.sql.*;

/**
 * Créé par Julien
 * à 12/12/2016.
 *
 * Classe permettant des accès a la base de donnée mail en particulier a la table mail;
 */
public class Mail_DAO {
    /*
    Toujours autant la flemme te taper ControleurBDD.getConnection() à chaque fois
     */
    private static Connection c = ControleurBDD.getConnection();

    /**
     * Methode de récupération du champ status du mail
     * @param id
     * @return true si le mail à été lu, false sinon
     */
    public static boolean getLu(int id){
        boolean exists = false;
        try {
            PreparedStatement ps = c.prepareStatement(
                    "SELECT mails.status FROM mails WHERE idMail=? ");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            ps.close();
            rs.beforeFirst();
            exists = rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exists;
    }


    /**
     * Methode permettant la modification du champ status de la table mail et de la ligne id
     * @param id
     * @param lu
     */
    public static void setLu(int id, boolean lu){
        try {
            Statement stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM mails WHERE idMail = " + id + ";");
            rs.updateBoolean("status", lu);
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Methode permettant de récupérer l'expéditeur du mail "id"
     * @param id
     * @return Instance de la classe Utilisateur correspondant à l'expéditeur
     */
    public static Utilisateur getExpediteur(int id){
        try {
            PreparedStatement ps = c.prepareStatement(
                    "SELECT mails.adresseExpediteur FROM mails WHERE idMail=? ;");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            rs.first();
            return new Utilisateur(rs.getString("adresseExpediteur"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Methode permettant de récupérer le destinataire du mail "id"
     * @param id
     * @return Instance de la classe Utilisateur correspondant au destinataire
     */
    public static Utilisateur getDestinataire(int id){
        try {
            PreparedStatement ps = c.prepareStatement(
                    "SELECT mails.adresseDestinataire FROM mails WHERE idMail=? ;");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            rs.first();
            return new Utilisateur(rs.getString("adresseDestinataire"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Methode permettant d'accéder au champ "texte" de la table mail et de la ligne "id"
     * @param id
     * @return Une String contenant le contenu du champ texte
     */
    public static String getTexte(int id){
        try {
            PreparedStatement ps = c.prepareStatement(
                    "SELECT mails.texte FROM mails WHERE idMail=? ;");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            rs.first();
            return rs.getString("texte");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Methode permettant de modifier le champ texte de la table mail et de la ligne id
     * @param id
     * @param texte
     */
    public static void setTexte(int id, String texte){
        try{
            PreparedStatement ps = c.prepareStatement("" +
                    "UPDATE mail.mails SET texte=?" +
                    "WHERE idMail=?;");
            ps.setString(1,texte);
            ps.setInt(2,id);
            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    /**
     * Methode permettant de récupérer le contenu du champ objet de la table mail à la ligne "id"
     * @param id
     * @return Une String contenant le contenu du champ cité plus haut
     */
    public static String getObjet(int id){
        try {
            PreparedStatement ps = c.prepareStatement(
                    "SELECT mails.objet FROM mails WHERE idMail=? ;");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            rs.first();
            return rs.getString("objet");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Methode permettant de modifier le champ objet de la table mail à la ligne id
     * @param id
     * @param objet
     */
    public static void setObjet(int id, String objet){
        try{
            PreparedStatement ps = c.prepareStatement("" +
                    "UPDATE mail.mails SET objet=?" +
                    "WHERE idMail=?;");
            ps.setString(1,objet);
            ps.setInt(2,id);
            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Methode permettantv de récupérer la date
     * @param id
     * @return un objet java.sql.Date
     */
    public static Date getDate(int id){
        Date date = null;
        try {
            PreparedStatement pstmt = c.prepareStatement(
                    "SELECT Date FROM mails WHERE IdMail = ?;"
            );
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            rs.first();
            date = rs.getDate("date");
            pstmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return date;
    }

}
