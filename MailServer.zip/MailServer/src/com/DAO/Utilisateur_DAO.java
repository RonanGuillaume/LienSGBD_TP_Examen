package com.DAO;

import com.controleur.ChampsUtilisateur;
import com.controleur.ControleurBDD;
import com.model.Utilisateur;

import java.sql.*;

/**
 * Créé par Pierre
 * à 12/12/2016.
 */
public class Utilisateur_DAO {

    /*
     * Juste pour m'éviter de réecrire ControleurBDD.getConnection() à chaque fois
     */
    private static Connection c = ControleurBDD.getConnection();


    /**
     * Cette methode permet de récupérer la valeur du champ passé en parramètre de l'utilisateur rensseigné
     * @param u
     * @param champ
     * @return la valeur du champ, pour une date, sa valeur en milisecondes, et pour un boolean, "true" ou "false". Renvoie null en cas d'erreurs
     */
    public static String getChamp(Utilisateur u, ChampsUtilisateur champ){
        try{
            PreparedStatement ps = c.prepareStatement("" +
                    "SELECT *" +
                    "FROM mail.utilisateurs " +
                    "WHERE adresseUtilisateur = ?;");
            //ps.setString(1,champ.toString());
            ps.setString(1,u.getAdresse());
            ResultSet rs = ps.executeQuery();
            if(!rs.isClosed()) {
                rs.first();
                switch(champ.getType()){
                    case("String"):
                        return rs.getString(champ.toString());
                    case("Date"):
                        return rs.getDate(champ.toString()).toString();
                    case("boolean"):
                        return rs.getString(champ.toString());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Cette methode permet de changer la valeur du champ passé en parramètre,
     *
     * @param u
     * @param champ
     * @param value Dans le cas d'une Date il faut passer la valeur de la date au format milis
     */
    public static void setChamp(Utilisateur u, ChampsUtilisateur champ, String value){

        try{
            PreparedStatement ps = c.prepareStatement("" +
                    "UPDATE mail.utilisateurs SET ? = ?" +
                    "WHERE adresseUtilisateur=?;");

            ps.setString(1,champ.toString());
            switch(champ.getType()){
                case("String"):
                    ps.setString(2,value);
                    break;
                case("Date"):
                    ps.setDate(2, new Date(Long.parseLong(value)));
                    break;
            }
            ps.setString(3,u.getAdresse());
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


}
