CREATE DATABASE mail;

CREATE TABLE mail.utilisateurs
(
    adresseUtilisateur VARCHAR(256) PRIMARY KEY NOT NULL,
    nom VARCHAR(128),
    prenom VARCHAR(128),
    dateNaissance DATETIME,
    numTel VARCHAR(15),
    mdp VARCHAR(256),
    Administrateur BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE UNIQUE INDEX utilisateurs_adresseUtilisateur_uindex ON mail.utilisateurs (adresseUtilisateur);

//OUI !! Je sais c'�tait pas une bonne id�e d'appeler la table avec le m�me nom que la BDD, mais une fois que je m'en suis rendu compe=te la base �tais cr�e et la table utilisateur aussi, du coup on a fait avec. 
CREATE TABLE mail.mail
(
    idMail INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    adresseExpediteur VARCHAR(256) NOT NULL,
    adresseDestinataire VARCHAR(256) NOT NULL,
    objet VARCHAR(1024),
    texte TEXT,
    status BOOLEAN DEFAULT FALSE ,
    date DATETIME,
    CONSTRAINT mail_utilisateurs_adresseDestinataire_fk FOREIGN KEY (adresseDestinataire) REFERENCES utilisateurs (adresseUtilisateur),
    CONSTRAINT mail_utilisateurs_adresseExpediteur_fk FOREIGN KEY (adresseExpediteur) REFERENCES utilisateurs (adresseUtilisateur)
);
CREATE UNIQUE INDEX mail_idMail_uindex ON mail.mail (idMail);

//Cr�er l'admin ici



